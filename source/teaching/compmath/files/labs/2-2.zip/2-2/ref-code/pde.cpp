/*
 * main.cpp
 *
 *  Created on: Apr 26, 2013
 *      Author: zhmurov
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <math.h>
#include <memory.h>

#define buf_size 1024

double** U;
double tau;
double h;
double T;
double X;
int N;
int M;

void writeU(const char* filename){
	FILE* out = fopen(filename, "w");
	int m, n;
	for(m = 0; m <= M; m++){
		fprintf(out, "%f\t", h*m);
		for(n = 0; n <= N; n+=N/10){
			fprintf(out, "%f\t", U[m][n]);
		}
		fprintf(out, "\n");
	}
	fclose(out);
}

void computeExplicit(){
	// Place implementation here
}

void computeImplicit(){
	// Place implementation here
}

int main(int argc, char* argv[]){
	tau = 0.00001; //Example
	h = 0.01;
	T = 0.01;
	X = 1.0;
	N = T/tau;
	M = X/h;
	U = (double**)calloc(M+1, sizeof(double*));
	int m, n;
	for(m = 0; m <= M; m++){
		U[m] = (double*)calloc(N+1, sizeof(double));
	}
	if(argc < 2){
		printf("Usage: %s <initial values filename>\n", argv[0]);
		exit(0);
	}
	FILE* input = fopen(argv[1], "r");
	char buffer[buf_size];
	for(m = 0; m <= M; m++){
		fgets(buffer, buf_size, input);
		U[m][0] = atof(buffer);
		printf("%f\n", U[m][0]);
	}
	fclose(input);
	for(n = 0; n <= N; n++){
		U[0][n] = 0.0;
		U[M][n] = 0.0;
	}

	computeExplicit();
	writeU("u_explicit.dat");
	computeImplicit();
	writeU("u_implicit.dat");
}
