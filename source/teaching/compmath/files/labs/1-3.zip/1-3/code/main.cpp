/*
 * main.cpp
 *
 *  Created on: 30.10.2012
 *      Author: zhmurov
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define BUF_SIZE 1024

double* x;
double* f;
int count;

double compute_linear(double xn, double xnp1, double fn, double fnp1, double arg){
	return (fnp1*(arg-xn)+fn*(xnp1-arg))/(xnp1-xn);
}

double linear(double arg){
	int i;
	if(arg <= x[0]){
		return compute_linear(x[0], x[1], f[0], f[1], arg);
	}
	if(arg >= x[count-1]){
		return compute_linear(x[count-2], x[count-1], f[count-2], f[count-1], arg);
	}
	for(i = 0; i < count-1; i++){
		if(arg > x[i] && arg < x[i+1]){
			return compute_linear(x[i], x[i+1], f[i], f[i+1], arg);
		}
	}
	return 0.0;
}

int main(int argc, char* argv[]){
	if(argc < 3){
		printf("Usage: %s input.dat output.dat\n", argv[0]);
		exit(0);
	}
	char buffer[BUF_SIZE];
	FILE* file = fopen(argv[1], "r");
	count = 0;
	int i = 0;
	if(file != NULL){
		while(fgets(buffer, BUF_SIZE, file) != NULL){
			count++;
		}
		if(count < 2){
			printf("At least two points needed for linear interpolation.\n");
			exit(0);
		}
		x = (double*)calloc(count, sizeof(double));
		f = (double*)calloc(count, sizeof(double));
		rewind(file);
		while(fgets(buffer, BUF_SIZE, file) != NULL){
			char* pch = strtok(buffer, " ");
			x[i] = atof(pch);
			pch = strtok(NULL, " \n\r");
			f[i] = atof(pch);
			i++;
		}
		fclose(file);
	} else {
		printf("Error opening '%s'\n", argv[0]);
	}
	printf("Data read:\n");

	for(i = 0; i < count; i++){
		printf("%f\t%f\n", x[i], f[i]);
	}
	file = fopen(argv[2], "w");
	double arg;
	for(arg = x[0]; arg <= x[count-1]; arg += 0.01){
		fprintf(file, "%f\t%f\n", arg, linear(arg));
	}
	fclose(file);
	return 0;
}
