#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <math.h>
#include <memory.h>

#define buf_size 1024

int rk_S;
double* rk_a;
double** rk_b;
double* rk_c;
double** rk_k;
double tolerance;

double pr_alpha = 1.0;
double pr_beta = 2.0;
double pr_gamma = 1.0;
double pr_delta = 1.5;

double* y;
int N = 2;


void readMethod(int argc, char* argv[]);
bool checkIfImplicit();

void initialConditions(double* result){
	result[0] = 1.0;
	result[1] = 0.05;
}

void computeF(double* result, double time, double* y){
	result[0] = (pr_alpha - pr_beta*y[1])*y[0];
	result[1] = (-pr_gamma + pr_delta*y[0])*y[1];
}

void printOutput(FILE* output, double time){
	fprintf(output, "%f\t", time);
	int k;
	for(k = 0; k < N; k++){
		fprintf(output, "%f\t", y[k]);
	}
	fprintf(output, "\n");
}

void computeImplicit(){
	//insert your code here
}

void computeExplicit(){
	//insert your code here
}

int main(int argc, char* argv[]){
	readMethod(argc, argv);
	int i;
	rk_k = (double**)calloc(rk_S, sizeof(double*));
	for(i = 0; i < rk_S; i++){
		rk_k[i] = (double*)calloc(N, sizeof(double));
	}
	y = (double*)calloc(N, sizeof(double));
	if(checkIfExplicit()){
		computeExplicit();
	} else {
		computeImplicit();
	}
	return 0;
}

void readMethod(int argc, char* argv[]){
	FILE* input;
	if(argc < 2){
		printf("Usage: %s <method filename>\n", argv[0]);
		exit(0);
	} else {
		input = fopen(argv[1], "r");
	}
	char buffer[buf_size];
	char* pch;
	fgets(buffer, buf_size, input);
	rk_S = atoi(buffer);
	int i, j;
	rk_a = (double*)calloc(rk_S, sizeof(double));
	rk_b = (double**)calloc(rk_S, sizeof(double*));
	for(i = 0; i < rk_S; i++){
		rk_b[i] = (double*)calloc(rk_S, sizeof(double));
	}
	rk_c = (double*)calloc(rk_S, sizeof(double));
	for(i = 0; i < rk_S; i++){
		fgets(buffer, buf_size, input);
		pch = strtok(buffer, " \t");
		rk_a[i] = atof(pch);
		for(j = 0; j < rk_S; j++){
			pch = strtok(NULL, " \t");
			rk_b[i][j] = atof(pch);
		}
	}
	fgets(buffer, buf_size, input);
	pch = strtok(buffer, " \t");
	for(i = 0; i < rk_S; i++){
		pch = strtok(NULL, " \t");
		rk_c[i] = atof(pch);
	}

	printf("The following RK method will be used:\n");
	printf("Number of stages: %d\n", rk_S);
	printf("Butcher's table:\n");
	for(i = 0; i < rk_S; i++){
		printf("%6.4f  |  ", rk_a[i]);
		for(j = 0; j < rk_S; j++){
			printf("%6.4f  ", rk_b[i][j]);
		}
		printf("\n");
	}
	printf("--------|--");
	for(i = 0; i < rk_S; i++){
		printf("--------");
	}
	printf("\n        |  ");
	for(i = 0; i < rk_S; i++){
		printf("%6.4f  ", rk_c[i]);
	}
	printf("\n");

	if(checkIfImplicit()){
		printf("The method is implicit.\n");
	} else {
		printf("The method is explicit.\n");
		fgets(buffer, buf_size, input);
		tolerance = atof(buffer);
		printf("Tolerance: %f\n", tolerance);

	}
	fclose(input);
}


bool checkIfImplicit(){
	if(rk_a[0] != 0.0){
		return false;
	}
	int i, j;
	for(i = 0; i < rk_S; i++){
		for(j = i; j < rk_S; j++){
			if(rk_b[i][j] != 0.0){
				return false;
			}
		}
	}
	return true;
}


