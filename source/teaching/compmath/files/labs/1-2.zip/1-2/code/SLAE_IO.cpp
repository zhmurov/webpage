#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <float.h>
#include <string.h>

#define buf_size 1024

int N;
double** A;
double* f;
double* u;

void readInput(const char* filename);
void printMatrix(double** A);
void printVector(double* r);

int main(int argc, char* argv[]){
	if(argc < 2){
		printf("Usage: %s <input filename>\n", argv[0]);
		exit(0);
	}
	readInput(argv[1]);
	return 0;
}

void printMatrix(double** A){
	int i, j;
	for(i = 0; i < N; i++){
		for(j = 0; j < N; j++){
			printf("%10.8f\t", A[i][j]);
		}
		printf("\n");
	}
}

void printVector(double* r){
	int i;
	for(i = 0; i < N; i++){
		printf("%10.8f\n", r[i]);
	}
}

void readInput(const char* filename){
	FILE* input = fopen(filename, "r");
	char buffer[buf_size];
	char* pch;
	fgets(buffer, buf_size, input);
	N = atoi(buffer);
	printf("N = %d\n", N);
	A = (double**)calloc(N, sizeof(double*));
	f = (double*)calloc(N, sizeof(double));
	u = (double*)calloc(N, sizeof(double));
	int i, j;
	for(i = 0; i < N; i++){
		A[i] = (double*)calloc(N, sizeof(double));
	}
	for(i = 0; i < N; i++){
		fgets(buffer, buf_size, input);
		pch = strtok(buffer, " \t");
		for(j = 0; j < N; j++){
			A[i][j] = atof(pch);
			pch = strtok(NULL, " \t");
		}
		f[i] = atof(pch);
	}
	printf("A:\n");
	printMatrix(A);
	printf("f:\n");
	printVector(f);
	fclose(input);
}
